from django.db import models

# Create your models here.
#primary key or id
class Album(models.Model):
    artist = models.CharField(max_length=256)
    album_title = models.CharField(max_length=256)
    genre = models.CharField(max_length=256)
    album_logo = models.CharField(max_length=1024)

class Song(models.Model):
    album = models.ForeignKey(Album, on_delete=models.CASCADE)